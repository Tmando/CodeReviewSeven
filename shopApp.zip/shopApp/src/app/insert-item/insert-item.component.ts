import { Component, OnInit } from '@angular/core';
import { FirebaseServiceService } from '../Services/firebase-service.service';

@Component({
  selector: 'app-insert-item',
  templateUrl: './insert-item.component.html',
  styleUrls: ['./insert-item.component.css'],
  providers: [FirebaseServiceService]
})
export class InsertItemComponent implements OnInit {
  categoryArray:Array<String>;
  categoryVal:string;
  nameItem:string;
  priceItem:number;
  availableItem:number;
  imgItem:string;
  attributionItem:string;
  count:number;
  items: Item[];

  constructor(private _firebaseService: FirebaseServiceService) { }

  ngOnInit() {
    this.categoryArray = new Array();
    this.categoryArray.push('new');
    this.categoryArray.push('sale');
    this.categoryArray.push('premium');
    this.categoryVal = 'new';
  }
  checkInput(){
    try{
      if(this.nameItem == ''){
        throw 'wrong input';

      }else if(this.imgItem == ''){
        throw 'wrong input';
      }
    }catch(e){
      console.log(e);
      return false;
    }
    return true;
  }
  addItem(){
    if(this.checkInput() == true){
      if(this.attributionItem != ''){
        this.createItem(this.nameItem,this.priceItem,this.availableItem,this.categoryVal,this.imgItem,this.attributionItem);
      }else{
        this.createItem(this.nameItem,this.priceItem,this.availableItem,this.categoryVal,this.imgItem,'');
      }
    }
  }

  createItem(name,price,available,category,image,attribution){
    let count:number = 10;
    let newItem={
      "id" : count,
      "name": name,
      "price":price,
      "available":available,
      "category":category,
      "image":image,
      "attribution":attribution
    }
    console.log(newItem);
    this._firebaseService.addItem(newItem);

  }

}
export interface Item{
  id: number;
  name: string;
  price:number;
  available:number;
  category:string;
  image:string;
  attribution:string;
}

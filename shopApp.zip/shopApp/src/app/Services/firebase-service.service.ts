import { Injectable } from '@angular/core';
import { AngularFireDatabase, FirebaseListObservable } from 'angularfire2/database';
import 'rxjs/add/operator/map';


@Injectable()
export class FirebaseServiceService {
  items: FirebaseListObservable<Item[]>;

  constructor(private af: AngularFireDatabase) {

  }
  getItems(category):FirebaseListObservable<Item[]>{
    if (category != null) {
      if(category == 'All'){
        this.items = this.af.list('/shop') as FirebaseListObservable<Item[]>;
      }else{
        this.items = this.af.list('/shop',{
            query: {
                orderByChild: 'category',
                equalTo: category
            }
            }) as FirebaseListObservable<Item[]>;

      }
    }else{
      this.items = this.af.list('/shop') as FirebaseListObservable<Item[]>;
    }
    return this.items;

  }
  addItem(newItem:Item){
    this.items = this.af.list('/shop') as FirebaseListObservable<Item[]>;
    return this.items.push(newItem);
  }

}


export interface Item{
  id: number;
  name: string;
  price:number;
  available:number;
  category:string;
  image:string;
  attribution:string;
}

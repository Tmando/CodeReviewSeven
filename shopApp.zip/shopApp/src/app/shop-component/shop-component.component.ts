import { Component, OnInit } from '@angular/core';
import { AngularFireModule } from 'angularfire2';
import { AngularFireDatabaseModule } from 'angularfire2/database';
import { AngularFireDatabase, FirebaseListObservable } from 'angularfire2/database';
import { AngularFireAuth } from 'angularfire2/auth';
import { Observable } from 'rxjs/Observable';
import { FirebaseServiceService } from '../Services/firebase-service.service';
import * as firebase from 'firebase/app';

@Component({
  selector: 'app-shop-component',
  templateUrl: './shop-component.component.html',
  styleUrls: ['./shop-component.component.css'],
  providers: [FirebaseServiceService]
})
export class ShopComponentComponent implements OnInit {
  items: Item[];
  categoryArray:Array<String>;
  categoryVal:string;

  constructor(private _firebaseService: FirebaseServiceService) { }

  ngOnInit() {
    this.categoryVal='All';
    this.getItems();
    this.categoryArray=new Array();
    this.categoryArray.push('All');
    this.categoryArray.push('new');
    this.categoryArray.push('sale');
    this.categoryArray.push('premium');

  }
  getItems(){
    this._firebaseService.getItems(this.categoryVal).subscribe(items=>{
      this.items = items;
      this.renderAllComponent();
    });
  }
  renderAllComponent(){
    let counter:number = 0;
    let strComponent:string = '';
    while(counter < this.items.length){
      if(counter%2==0){
        strComponent+='<div class=\"row itemRow\">';
      }
      strComponent+=this.renderOneComponent(this.items[counter]);
      if(counter%2!=0){
        strComponent+='</div>';
      }
      counter += 1;
    }
    console.log(strComponent);
    document.getElementById("shopItems").innerHTML=strComponent;

  }
  renderOneComponent(item:Item):string{
    let itemStr:string = '';
    if(item.category == 'new'){
      itemStr = 'itemNewStyle';
    }else{
      itemStr = 'itemSaleStyle';
    }
    let strDiv:string = "<div class=\"col-lg-6 col-md-6 col-sm-6 col-xs-6 col-xl-6\">";
      strDiv+= "<div class=\"row\">";
        strDiv+= "<div class=\"col-lg-4 col-md-4 col-sm-4 col-xs-4 col-xl-4\">";
        strDiv+= "<img class=\"img-responsive\" src=\""+ item.image +"\">";
        strDiv+= "</div>";
        strDiv+= "<div class=\"col-lg-6 col-md-6 col-sm-6 col-xs-6 col-xl-6 " +itemStr+ "\">";
          strDiv += "<ul class=\"myList\">";
            strDiv += "<li>Name: "+item.name + "</li>";
            strDiv += "<li>Available: "+ item.available +"</li>";
            strDiv += "<li>Category: "+item.category +"</li>";
            strDiv += " <li>Price: " + item.price + "€"+"</li>";
          strDiv += "</ul>";
        strDiv+="</div>";
      strDiv+="</div>";
    strDiv+= "</div>";
    return strDiv;
    /*
    let strDiv:string = '<div class=\"col-lg-4\">';
      strDiv += '<div class=\"row\">';
        let imgDiv:string = '<div class=\"col-lg-6\">';
          let imgTag:string = '<img class=\"img-responsive\" src=\"' + item.image +'\"'+ '>';
          imgDiv+=imgTag;
        imgDiv+='</div>';
        strDiv += imgDiv;
          let contentDiv:string = '<div class=\"col-lg-6\">';
            contentDiv += '<ul>';
              contentDiv += '<li>' +'Name: ' + item.name +'</li>';
              contentDiv += '<li>' +'Price: ' + item.price +'</li>';
              contentDiv += '<li>' +'Avabliable: ' + item.avabliable +'</li>';
              contentDiv += '<li>' +'Category: ' + item.category +'</li>';
            contentDiv += '</ul>';
          contentDiv+='</div>';
        strDiv+=contentDiv;


      strDiv += '</div>';
    strDiv += '</div>';
    */
  }


}
export interface Item{
  id: number;
  name: string;
  price:number;
  available:number;
  category:string;
  image:string;
  attribution:string;
}

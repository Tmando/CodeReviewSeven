import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule }   from '@angular/forms';
import { AppComponent } from './app.component';
import { AngularFireModule } from 'angularfire2';
import { AngularFireDatabaseModule } from 'angularfire2/database';
import { AngularFireAuthModule } from 'angularfire2/auth';
import { ShopComponentComponent } from './shop-component/shop-component.component';
import { NavbarComponent } from './navbar/navbar.component';
import { RouterModule, Routes } from '@angular/router';
import {InsertItemComponent} from './insert-item/insert-item.component';



export const firebaseConfig = {
  apiKey: "AIzaSyB2GAtOZZRPB6vWgVmPEhXnY3edkbII3eM",
    authDomain: "fruitproject-6889e.firebaseapp.com",
    databaseURL: "https://fruitproject-6889e.firebaseio.com",
    projectId: "fruitproject-6889e",
    storageBucket: "",
    messagingSenderId: "51835284136"
};
const appRoutes: Routes = [
 {
   path: '', component: ShopComponentComponent
 },
 {
   path: 'addItem', component: InsertItemComponent
 },
];
@NgModule({
  declarations: [
    AppComponent,
    ShopComponentComponent,
    NavbarComponent,
    InsertItemComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AngularFireModule.initializeApp(firebaseConfig),
    AngularFireDatabaseModule,
    AngularFireAuthModule,
    RouterModule.forRoot(appRoutes)

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
